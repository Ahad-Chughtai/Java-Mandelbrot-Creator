import java.awt.image.BufferedImage;
import javax.swing.ImageIcon;
import java.awt.Image;

import javax.swing.*;
import javax.swing.JLabel;
import javax.swing.JPanel;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class MandelbrotCreator extends JFrame implements MouseListener
{
    static BufferedImage Mandelbrot;
    static JLabel l;
    static int height = 711;
    static int width = 1358;
    static boolean newFrame = true;
    int MouseY = 0;
    int MouseX = 0;

    MandelbrotCreator()
    {
        setVisible(true);
        setBounds(0, 0, 1358, 711);
        setTitle("Mandelbrot Set");
        addMouseListener(this);

        JPanel p = new JPanel();
        p.setBounds(0, 0, 1358, 711);
        p.setLayout(null);

        l = new JLabel(new ImageIcon(Mandelbrot));
        l.setBounds(-0, 0, 1358, 711);

        p.add(l);

        add(p);

        System.out.print("This program creates the Mandelbrot set on a blank canvas using a mathmatical formula that was discovered by Benoit Mandelbrot in 1980.\n\nThe Mandelbrot set is a fractal which means you can zoom-in on it and you will keep seeing the same image repeating infinetly.\n\nYou can change the colors of the image by changing the hex code of the Col2 integer.\n\nYou can also change the x and y doubles to anything between -1 and 1 for a different shape.\n\nYou can click anywhere on the image to zoom in on that part.\n\nWarning: This program cannot handle too many zoom-ins.");
    }

    public static void main (String[] args)
    {
        int max = 50;
        int black = 0x000000;
        int Col2 = 0xD4F1F4; //More cool hex colors - D4F1F4, FF7F7F, 080FFF, FFD580, 008080
        Mandelbrot = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

        for (int row = 0; row < height; row++)
        {
            for (int col = 0; col < width; col++)
            {
                double cWidth = (col - width/2)*4.0/width;
                double cHeight = (row - height/2)*4.0/width;
                double x = 0;
                double y = 0;
                int iterations = 0;

                while (x * x + y * y < 4 && iterations < max)
                {
                    double newX = x * x - y * y + cWidth;
                    y = 2 * x * y + cHeight;
                    x = newX;

                    iterations++;
                }

                if (iterations < max )
                {
                    Mandelbrot.setRGB(col, row, iterations*Col2);
                }
                else
                {
                    Mandelbrot.setRGB(col, row, black);
                }
            }
        }

        if (newFrame)
        {
            new MandelbrotCreator();
            newFrame = false;
        }
    }

    public void mouseClicked(MouseEvent e)
    {
    }

    public void mousePressed(MouseEvent e)
    {
        // You can zoom in 4 times before it crashes because of memory. If you want to zoom in more the memory size needs to be increased.
        height+=2000;
        width+=2000;

        MouseX-=e.getX()*2;
        MouseY-=e.getY()*2;

        main(null);
        l.setIcon(new ImageIcon(Mandelbrot));
        l.setBounds(MouseX,MouseY, width, height);
        System.out.print("\n\nZoom");
    }

    public void mouseReleased(MouseEvent e)
    {
    }

    public void mouseEntered(MouseEvent e)
    {
    }

    public void mouseExited(MouseEvent e)
    {
    }
}